# HADIX website starter

A responsive multi-page website starter for HADIX, with HTML, shared CSS, and JavaScript.

## Files
- `index.html` — homepage
- `about.html` — company story, mission, vision, values
- `services.html` — service overview
- `projects.html` — filterable project concepts
- `blog.html` — starter blog summaries
- `contact.html` — contact form demo
- `css/style.css` — shared styling, responsive layout, animations
- `js/main.js` — mobile navigation, scroll reveal, project filters, form validation

## Run locally
1. Extract the ZIP.
2. Open the `hadix-website` folder in VS Code or another editor.
3. Open `index.html` in your browser. For a smoother local development experience, use VS Code's Live Server extension or another static local server.
4. Edit the text, service descriptions, colors, and links to match the real company.

## Before publishing
- Replace `hello@example.com` and other placeholder contact details.
- Project cards are illustrative concepts, not claims of completed work.
- The contact form only validates fields in the browser; it does not send email. Connect it to a backend or trusted form service before launch.
- The homepage uses a remote sample video and remote image poster. Internet access is needed for that video; replace it with your own licensed video in `assets/` if desired.
- Google Fonts and the sample video are loaded from external services. For fully self-hosted operation, download licensed assets and update their paths.
- Test every page and form on mobile and desktop before publishing.

## Deploy
This is a static website. You can deploy the folder to a static hosting provider such as GitHub Pages, Netlify, or Cloudflare Pages. Upload the site files with `index.html` at the published root.
